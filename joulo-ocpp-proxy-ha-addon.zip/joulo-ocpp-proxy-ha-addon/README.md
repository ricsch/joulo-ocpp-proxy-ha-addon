# Rico's Home Assistant Add-on Repository

## Add-ons in this repository

### [Joulo OCPP Proxy](./joulo-ocpp-proxy)

UI-configurable Home Assistant packaging of the open-source
[joulo-ocpp-proxy](https://github.com/joulo-nl/joulo-ocpp-proxy) OCPP
splitter — lets one charge point be controlled by a primary OCPP backend
while mirroring all traffic (meter values, sessions) to a secondary,
read-only backend. See the [add-on README](./joulo-ocpp-proxy/README.md) for
details and configuration options.

## Installation

1. In Home Assistant: Settings → Add-ons → Add-on Store
2. ⋮ (top right) → Repositories
3. Add this repository's URL:
   `https://github.com/YOUR_GITHUB_USERNAME/joulo-ocpp-proxy-ha-addon`
4. The add-on(s) above will appear in the store.
