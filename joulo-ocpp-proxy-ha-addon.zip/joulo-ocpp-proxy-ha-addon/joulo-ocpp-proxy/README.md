# Joulo OCPP Proxy — Home Assistant Add-on

A thin, UI-configurable Home Assistant wrapper around
[joulo-nl/joulo-ocpp-proxy](https://github.com/joulo-nl/joulo-ocpp-proxy), an
open-source OCPP 1.6 proxy/splitter.

## Why this exists

Many wallboxes only accept **one** OCPP backend URL. If you want a commercial
backend (billing, a charging network, a roaming platform, ...) to keep full
control of your charger, but *also* want a local energy management system
(e.g. [evcc](https://evcc.io) or Home Assistant) to see live meter/session
data, you need something in between that:

- forwards the charger's connection to your **primary** backend, which keeps
  full control (it can send commands back to the charger)
- mirrors the same traffic to one or more **secondary** backends, read-only

This add-on packages that proxy for Home Assistant OS/Supervised, with the
proxy's settings exposed as normal Add-on **Configuration** fields — no SSH,
no manual file edits, no rebuilding required to change a URL.

## Installation

1. Settings → Add-ons → Add-on Store → ⋮ → Repositories
2. Add: `https://github.com/YOUR_GITHUB_USERNAME/joulo-ocpp-proxy-ha-addon`
3. Install "Joulo OCPP Proxy" from the store
4. Configuration tab: set `primary_csms_url` and `secondary_csms_urls`
5. Start the add-on
6. Point your charger's OCPP backend URL at
   `ws://<home-assistant-ip>:9000/charger` (path depends on your charger;
   check its manual — some chargers append their own ID automatically)

## Configuration options

| Option | Description |
|---|---|
| `primary_csms_url` | The OCPP backend that keeps full control (start/stop, current limits, ChangeConfiguration, ...). |
| `secondary_csms_urls` | A read-only mirror backend. Receives all OCPP traffic; its own commands back to the charger are ignored by design. |
| `log_level` | `debug` / `info` / `warn` / `error`. Use `debug` to see every OCPP message while diagnosing a connection issue. |

## Known limitation

Only the **primary** backend can control the charger. A secondary backend
that tries to actively command the charger (e.g. requesting a
`TriggerMessage`/`BootNotification`, or starting a session) will see its
request time out — this is intentional, not a bug. If you need a system to
both *control* charging (e.g. PV-surplus logic) and have a commercial backend
receive billing data, put the controlling system in `primary_csms_url` and
the billing backend in `secondary_csms_urls`.

## Multiple secondary backends

`secondary_csms_urls` currently accepts one URL. If you need more than one
mirror target, open an issue or PR — the underlying proxy supports a list,
this add-on's schema would just need a small extension (comma-separated
string split, or a `list()` schema type).

## Credit

All actual OCPP proxying logic comes from the upstream
[joulo-nl/joulo-ocpp-proxy](https://github.com/joulo-nl/joulo-ocpp-proxy)
project. This repository only adds the Home Assistant add-on packaging
(`config.yaml`, `Dockerfile`, and a small `run.sh` that bridges Supervisor's
`options.json` to the environment variables the upstream image expects).
