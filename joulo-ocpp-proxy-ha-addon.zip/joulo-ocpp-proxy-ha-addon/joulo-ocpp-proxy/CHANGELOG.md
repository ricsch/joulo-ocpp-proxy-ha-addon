# Changelog

## 1.1.0

- Options are now configurable via the Home Assistant Add-on Configuration UI
  (`primary_csms_url`, `secondary_csms_urls`, `log_level`) instead of being
  baked into `config.yaml`'s `environment` block.
- Fixed: run as `root` so the container can read Supervisor's
  `/data/options.json` (the upstream base image drops to a non-root user).

## 1.0.0

- Initial packaging of joulo-nl/joulo-ocpp-proxy as a Home Assistant add-on.
