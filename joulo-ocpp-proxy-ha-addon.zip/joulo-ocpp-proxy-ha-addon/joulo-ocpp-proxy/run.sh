#!/bin/sh
set -e
CONFIG_PATH=/data/options.json

PRIMARY_CSMS_URL=$(node -e "console.log(JSON.parse(require('fs').readFileSync('$CONFIG_PATH','utf8')).primary_csms_url)")
SECONDARY_CSMS_URLS=$(node -e "console.log(JSON.parse(require('fs').readFileSync('$CONFIG_PATH','utf8')).secondary_csms_urls)")
LOG_LEVEL=$(node -e "console.log(JSON.parse(require('fs').readFileSync('$CONFIG_PATH','utf8')).log_level || 'info')")

export PRIMARY_CSMS_URL
export SECONDARY_CSMS_URLS
export LOG_LEVEL

exec docker-entrypoint.sh node dist/index.js
